CREATE DATABASE Movies;
GO

USE Movies;
GO


CREATE TABLE tblCountry (
    FilmCountryID INT PRIMARY KEY,
    Country VARCHAR(100) NOT NULL
);


CREATE TABLE tblLanguage (
    FilmLanguageID INT PRIMARY KEY,
    Language VARCHAR(100) NOT NULL
);


CREATE TABLE tblStudio (
    FilmStudioID INT PRIMARY KEY,
    StudioName VARCHAR(100) NOT NULL,
    City VARCHAR(100),
    State VARCHAR(100),
    PostalCode VARCHAR(20),
    DateOfBuild DATETIME NOT NULL
);


CREATE TABLE tblDirector (
    DirectorID INT PRIMARY KEY,
    DirectorName VARCHAR(150) NOT NULL,
    DirectorDOB DATE NOT NULL,
    DirectorGender CHAR(1))
;


CREATE TABLE tblActor (
    ActorID INT PRIMARY KEY,
    ActorName VARCHAR(150) NOT NULL,
    ActorDOB DATE NOT NULL,
    ActorGender CHAR(1))
;


CREATE TABLE tblFilm (
    FilmID INT PRIMARY KEY,
    FilmName VARCHAR(200) NOT NULL,
    FilmRunTimeMinutes INT NOT NULL,
    FilmReleaseDate DATETIME NOT NULL,
    FilmBoxOfficeDollars MONEY,
    DirectorID INT NOT NULL FOREIGN KEY REFERENCES tblDirector(DirectorID),
    FilmLanguageID INT NOT NULL FOREIGN KEY REFERENCES tblLanguage(FilmLanguageID),
    FilmCountryID INT NOT NULL FOREIGN KEY REFERENCES tblCountry(FilmCountryID),
    FilmStudioID INT NOT NULL FOREIGN KEY REFERENCES tblStudio(FilmStudioID),
    CONSTRAINT CK_FilmReleaseDate CHECK (FilmReleaseDate >= '1970-01-01')
);