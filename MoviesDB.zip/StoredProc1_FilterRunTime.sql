CREATE PROC spFilmCriteria(@MinLength AS INT)
AS
BEGIN

SELECT FilmName, FilmRunTimeMinutes
FROM tblfilm
WHERE
	 FilmRunTimeMinutes>@MinLength
ORDER BY FilmRunTimeMinutes ASC

END
