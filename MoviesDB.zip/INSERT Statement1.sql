-- Insert statement to give each table records.
INSERT INTO tblCountry (FilmCountryID, Country) VALUES (1,'United States');
INSERT INTO tblCountry (FilmCountryID, Country) VALUES (2,'Spain');
INSERT INTO tblCountry (FilmCountryID, Country) VALUES (3,'France');
INSERT INTO tblCountry (FilmCountryID, Country) VALUES (4,'England');
INSERT INTO tblCountry (FilmCountryID, Country) VALUES (5,'New Zealand');
INSERT INTO tblCountry (FilmCountryID, Country) VALUES (6,'Japan');


INSERT INTO tblLanguage (FilmLanguageID, Language) VALUES (1,'English');
INSERT INTO tblLanguage (FilmLanguageID,Language) VALUES (2,'Spanish');
INSERT INTO tblLanguage (FilmLanguageID,Language) VALUES (3,'French');
INSERT INTO tblLanguage (FilmLanguageID,Language) VALUES (4,'German');
INSERT INTO tblLanguage (FilmLanguageID,Language) VALUES (5,'Japanese');

INSERT INTO tblStudio (FilmStudioID, StudioName, City, State, PostalCode, DateOfBuild)
VALUES (1,'Paramount Studios', 'Hollywood', 'CA', '90028', '1920-01-01');

INSERT INTO tblStudio (FilmStudioID,StudioName, City, State, PostalCode, DateOfBuild)
VALUES (2,'Warner Bros', 'Burbank', 'CA', '91505', '1923-05-15');

INSERT INTO tblStudio (FilmStudioID,StudioName, City, State, PostalCode, DateOfBuild)
VALUES (3,'Universal Pictures', 'Universal City', 'CA', '91608', '1912-03-10');

INSERT INTO tblStudio (FilmStudioID,StudioName, City, State, PostalCode, DateOfBuild)
VALUES (4,'20th Century Fox', 'Los Angeles', 'CA', '90036', '1935-07-04');

INSERT INTO tblStudio (FilmStudioID,StudioName, City, State, PostalCode, DateOfBuild)
VALUES (5,'Columbia Pictures', 'Culver City', 'CA', '90232', '1918-11-11');

INSERT INTO tblStudio (FilmStudioID,StudioName, City, State, PostalCode, DateOfBuild)
VALUES (6,'Lionsgate Films', 'Santa Monica', 'CA', '90401', '1995-05-20');

INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (1,'Steven Spielberg', '1946-12-18', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (2,'Christopher Nolan', '1970-07-30', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (3,'Quentin Tarantino', '1963-03-27', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (4,'Martin Scorsese', '1942-11-17', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (5,'Ridley Scott', '1937-11-30', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (6,'James Cameron', '1954-08-16', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (7,'Peter Jackson', '1961-10-31', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (8,'David Fincher', '1962-08-28', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (9,'Tim Burton', '1958-08-25', 'M');
INSERT INTO tblDirector (DirectorID, DirectorName, DirectorDOB, DirectorGender)
VALUES (10,'Clint Eastwood', '1930-05-31', 'M');

INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (1, 'Leonardo DiCaprio', '1974-11-11', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (2, 'Brad Pitt', '1963-12-18', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (3, 'Tom Hanks', '1956-07-09', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (4, 'Johnny Depp', '1963-06-09', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (5, 'Morgan Freeman', '1937-06-01', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (6, 'Robert De Niro', '1943-08-17', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (7, 'Al Pacino', '1940-04-25', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (8, 'Christian Bale', '1974-01-30', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (9, 'Matt Damon', '1970-10-08', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (10, 'Hugh Jackman', '1968-10-12', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (11, 'Daniel Craig', '1968-03-02', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (12, 'Mark Wahlberg', '1971-06-05', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (13, 'Jude Law', '1972-12-29', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (14, 'George Clooney', '1961-05-06', 'M');
INSERT INTO tblActor (ActorID, ActorName, ActorDOB, ActorGender) VALUES (15, 'Will Smith', '1968-09-25', 'M');