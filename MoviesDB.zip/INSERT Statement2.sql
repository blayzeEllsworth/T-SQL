-- I used a generate movie name. Feel free to change yours as you see fit.
INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (1, 'Film 1', 120, '1971-01-01', 1000000, 1, 1, 1, 1);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (2, 'Film 2', 110, '1972-06-01', 1500000, 2, 1, 1, 2);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (3, 'Film 3', 140, '1973-07-15', 2000000, 3, 1, 1, 3);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (4, 'Film 4', 100, '1974-08-20', 2500000, 4, 1, 1, 4);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (5, 'Film 5', 150, '1975-04-22', 3000000, 5, 1, 1, 5);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (6, 'Film 6', 115, '1996-09-10', 3500000, 6, 1, 1, 6);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (7, 'Film 7', 125, '1977-01-01', 4000000, 7, 1, 1, 1);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (8, 'Film 8', 135, '1978-06-01', 4500000, 8, 1, 1, 2);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (9, 'Film 9', 105, '1979-07-15', 5000000, 9, 1, 1, 3);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (10, 'Film 10', 145, '1980-08-20', 5500000, 10, 2, 1, 4);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (11, 'Film 11', 120, '1981-04-22', 6000000, 1, 1, 1, 5);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (12, 'Film 12', 110, '1997-09-10', 6500000, 2, 1, 1, 6);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (13, 'Film 13', 140, '1983-01-01', 7000000, 3, 1, 1, 1);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (14, 'Film 14', 100, '1984-06-01', 7500000, 4, 1, 1, 2);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (15, 'Film 15', 150, '1985-07-15', 8000000, 5, 1, 1, 3);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (16, 'Film 16', 115, '1986-08-20', 8500000, 6, 1, 1, 4);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (17, 'Film 17', 125, '1987-04-22', 9000000, 7, 1, 1, 5);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (18, 'Film 18', 135, '1998-09-10', 9500000, 8, 1, 1, 6);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (19, 'Film 19', 105, '1989-01-01', 10000000, 9, 1, 1, 1);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (20, 'Film 20', 145, '1990-06-01', 10500000, 10, 3, 1, 2);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (21, 'Film 21', 120, '1991-07-15', 11000000, 1, 1, 1, 3);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (22, 'Film 22', 110, '1992-08-20', 11500000, 2, 1, 1, 4);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (23, 'Film 23', 140, '1993-04-22', 12000000, 3, 1, 4, 5);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (24, 'Film 24', 100, '1999-09-10', 12500000, 4, 1, 4, 6);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (25, 'Film 25', 150, '1995-01-01', 13000000, 5, 1, 4, 1);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (26, 'Film 26', 115, '1996-06-01', 13500000, 6, 1, 4, 2);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (27, 'Film 27', 125, '1997-07-15', 14000000, 7, 1, 5, 3);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (28, 'Film 28', 135, '1998-08-20', 14500000, 8, 1, 5, 4);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (29, 'Film 29', 105, '1999-04-22', 15000000, 9, 1, 5, 5);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (30, 'Film 30', 145, '2000-09-10', 15500000, 10, 1, 5, 6);

INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (31, 'Film 31', 120, '2001-01-01', 16000000, 1, 1, 2, 1);


INSERT INTO tblFilm (FilmID, FilmName, FilmRunTimeMinutes, FilmReleaseDate, FilmBoxOfficeDollars, DirectorID, FilmLanguageID, FilmCountryID, FilmStudioID)
VALUES (32, 'Film 32', 110, '2002-06-01', 16500000, 2, 1, 6, 2);